from pathlib import Path
import hashlib, json, zipfile, difflib, datetime, re

E = Path(__file__).resolve().parent
ROOT = E.parent.parent
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def write(name, obj): (E/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

index=read(E/'DIRECTORY_INDEX_AND_HASHES.json')
post=[]
for item in index:
    p=ROOT/item['path']
    actual=h(p) if p.is_file() else None
    post.append({'path':item['path'],'before_sha256':item['sha256'],'after_sha256':actual,'unchanged':actual==item['sha256']})
write('ORIGINAL_FILES_POSTRUN.json',post)
changed=[x for x in post if not x['unchanged']]
if changed: raise RuntimeError('Unknown original changes preserved; inspect ORIGINAL_FILES_POSTRUN.json')

runs=['natural-compile-01','raw-short-write-01','natural-adapter-coastal-01','natural-adapter-coastal-fixed-02','natural-adapter-plateau-fixed-01']
results=[read(E/r/'VERIFIED_RESULT.json') for r in runs]
required=[r for r in results if r['run']!='natural-adapter-coastal-01']
if not all(r['strict_pass'] for r in required): raise RuntimeError('Required suites not all strictly passed')

diffs=[]
for name, paths in [('raw-short-write',['core/ai_gm_rebuilt/engine.gd']),('natural-save-identity',['view/generated_natural_coast_basic/adapter.gd','view/generated_natural_coast_basic/engine.gd','tests/natural_coast_basic/test_adapter.gd'])]:
    text=''
    for path in paths:
        before=ROOT/'public-v30'/path
        after=ROOT/'public-candidates'/name/'project'/path
        text+=''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),after.read_text(encoding='utf-8').splitlines(True),fromfile='public-v30/'+path,tofile=name+'/'+path))
        diffs.append({'candidate':name,'path':path,'public_v30_sha256':h(before),'candidate_sha256':h(after)})
    (E/(name+'_PUBLIC_V30_DIFF.patch')).write_text(text,encoding='utf-8')
write('CANDIDATE_DIFF_BINDING.json',diffs)

report={
 'status':'specified_local_suites_completed_independent_unadopted_candidates',
 'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'plan_url':'https://chatgpt.com/space/page_5d6b6711bbac8191a2bbaf758e03cd4f',
 'plan_sequence_read':108,
 'original_files_indexed':len(index),'original_files_unchanged':len(post),'original_changes':changed,
 'runs':results,
 'fix':read(E/'natural-test-type-fix/FIX_MANIFEST.json'),
 'scope':'public-v30 source and resource scope; Raw and Natural independently copied, executed, and verified; not combined or adopted',
 'known_public_project_exception':{'public_project_sha256':'34343acc9519c5479f0c0e86028fa7ed47bf207147d43a804c71ab504358c1fd','old_raw_manifest_project_sha256':'0b35574f45a5b50307636bb3eee790a9c99be785ce3dc30c2b44e1c666dc0038','old_manifest_edited':False},
 'guard':{'source_cs_sha256':'c2add699950e8985f88dc581a76a9eda36549c9c14ff0ada2fe6f4012c53c957','source_ps_sha256':'f831a84e71f692fc851945b001cfc98092b7049fb3b48d0f5099fa49e016c5f8','budget':'min(actual physical memory, 8 GiB)','reserve_bytes':536870912,'small_job_commit_limit_bytes':1073741824,'max_seconds':120,'combined_output_limit_bytes':65536,'fresh_powershell_compilation_per_run':True,'guard_fault_injection':False,'rss_peak_claimed':False},
 'not_executed':['Godot version rerun','user:// probe rerun','Main/full UI/performance/real-model/player-journey tests','actual OS short writes','crash/power-loss durability','formal v30 adoption','function video recording'],
 'video_constraint':'Existing unchanged v3 guard requires --headless and rejects non-headless Godot. No graphical recording was attempted and no test-output video is represented as a gameplay demonstration. A bounded guarded recording path must be established before actual feature recording.',
 'next_priority':'T03 shared temporary filename / concurrent writers and TOCTOU destination overwrite protection, in a separate candidate with deterministic race tests. Keep Raw and Natural separate until composition is separately pinned and tested.',
 'library_upload_retried':False,'cancelled_or_rejected_publication_retried':False,'readme_modified':False,'actions_added':False,'repository_visibility_or_history_changed':False,
 'model_requested':'gpt-6.1-sol','model_identity_verification':'Not exposed to this agent by callable tools; no claim of a verified model switch.',
}
write('DELIVERY_RESULT.json',report)

table='| 检查 | 真实结果 | Godot PID | 秒 | Job 提交峰值 MiB |\n|---|---|---:|---:|---:|\n'
for r in results:
    label=r['run']
    outcome=('4/4' if r['checks']==4 else f"{r['checks']} 项，T03 {r['t03_executed']}/13" if r['checks'] else f"{r['cases']}/10 场景，{r['assertions']} 断言" if r['cases'] else '解析失败，运行用例 0')
    table+=f"| {label} | {outcome} | {r['godot_pid']} | {r['elapsed_seconds']} | {r['job_peak_commit_bytes']/1048576:.2f} |\n"
md='''# Words and Perils 本地测试交付

本轮明确范围已执行：Natural 四项空对象、Raw 十个场景、Natural 两种配方的完整 adapter。全部通过结果均绑定源码；原 Natural 测试的三处类型推断错误及失败回执保留，测试修复只在新可弃副本应用。候选独立，正式 v30 保持。

'''+table+'''
通过的四组均退出 0，stderr 为空，无 Godot ERROR/WARNING；Job 为空、Reader 完成、记录的进程句柄和守卫宿主退出。峰值为内核 Job 的提交内存，不是任务物理 RSS。守卫每次在新 PowerShell 核 SHA 并编译，Small 1 GiB、120 秒、64 KiB 合计输出、512 MiB 预留保持，无守卫故障注入。

Raw 的 7 项内存后端场景和 3 项真实隔离文件场景分列；没有验证实际磁盘短写、断电或崩溃耐久。Natural 每配方新增 13 项 T03 均逐项输出 passed；运行前后 traversal_policy.gd 和全复制文件 SHA 一致。测试入口继承原脚本，先核双 API 隔离路径，再执行原测试；观察器只记录 T03 断言，原测试断言逻辑不改。

修复差异只有测试脚本三处 `:=` 改为 `: Dictionary =`。原测试 SHA 为 99d750960ed2ba6197b5e624044a31276accd78c32aea78e000661179d2c66df；修复 SHA 为 60e46a3b5b607d3ba5cbe3634ebcd6bd3ebbfc98fa10d4bad8732ea95b5a0ba2。Natural 两份生产源码及 Raw 生产源码保持原候选 SHA，旧 manifest 没有修改。

public-v30 project.godot 的 SHA 为 34343acc9519c5479f0c0e86028fa7ed47bf207147d43a804c71ab504358c1fd；Raw 旧清单仍指向 0b35574f45a5b50307636bb3eee790a9c99be785ce3dc30c2b44e1c666dc0038。本次只验 public-v30 候选范围，不冒称旧私有分发全匹配。

8,136 个原有非 Git 文件已建立路径、大小和 SHA 索引，并终核全部保持。public-input、public-v30、原候选、原 74、Play、真实存档及原探针不改。总计划读取第 108 次更新，继续维护原链接，不另建总计划。先前 dot 连接聊天处于 idle；本轮直接本机执行，没有通过该聊天派发或消息协调。

原探针回执 82,571 字节及 SHA 7588f7eee645f386f03275405dba30927fac8b99e388c1d3af1e3868214641e9 保持。19 个回执绑定文件重新核 SHA 全同，两 API 同路径，marker SHA 2a55e35151a6d5685c6de1a66a051221185ebd1d9e111e68696f859ba9f806cc 匹配，路径拒绝与 return 均在写入前。独立勘误将运行北京时间记为 18:49:33.6029581 至 18:49:34.3005407；原 UTC 和回执不改。版本与 probe 均未重跑。

首次证据整理、过早启动器和证据后处理的工具错误另有记录；过早启动器未找到 SPEC，发生于 Godot 创建前。Natural 原测试失败和定点解析诊断均保留，不被通过结果覆盖。

未执行 Main、UI 整版、性能、真实模型、玩家完整旅程或正式采用。现有 v3 必须 headless，尚未录制图形功能视频；没有放松守卫启动图形进程。模型请求为 gpt-6.1-sol，但当前工具未暴露模型身份/切换接口，因此未把模型切换记为已验证。

下一项开发优先补 T03 共享 `.tmp`、并发写入与检查后目标变化的覆盖保护，另建候选和确定性竞争用例。Raw/Natural 合成仍须独立身份与测试闭环。本轮未重试 Library 403 或此前取消/拒绝的发布动作。
'''
(E/'REPORT.md').write_text(md,encoding='utf-8')
guide='''# 本轮证据目录索引

这是本轮目录导览；唯一项目总计划仍为 https://chatgpt.com/space/page_5d6b6711bbac8191a2bbaf758e03cd4f 。

| 路径 | 用途 |
|---|---|
| DIRECTORY_INDEX_AND_HASHES.json / DIRECTORY_SUMMARY.json | 原目录路径、大小、SHA 及汇总 |
| LOCAL_PREFLIGHT.json / THREAD_OCCUPANCY.json | 直接本机执行与可见聊天占用快照 |
| MANIFEST_AND_AUTHORITY_AUDIT.json | 344 条清单/权威源码核对，已知 project 范围例外单列 |
| PROBE_EVIDENCE_AUDIT.json / PROBE_ORIGINAL_HASH_BINDING.json | 原探针源码、spec、双 API 路径、marker 和原回执 SHA |
| PROBE_HONG_KONG_ERRATUM*.json | 独立时间勘误，原探针文件不改 |
| natural-compile-01 | Natural 四项检查真实结果、完整复制字节记录及守卫日志 |
| raw-short-write-01 | Raw 10 场景/57 断言，内存与真实文件范围见 SUITE_RESULT |
| natural-adapter-coastal-01 / natural-adapter-parse-diagnostic-01 | 原测试解析失败与定点诊断 |
| natural-test-type-fix | 三行测试类型修复、独立 manifest 与 patch |
| natural-adapter-coastal-fixed-02 / natural-adapter-plateau-fixed-01 | 两配方全套、13 项 T03 明细、policy 恢复哈希 |
| 每组 SOURCE_MAP / SOURCE_POSTRUN / VERIFIED_RESULT | 复制前后绑定全部文件，suite 原脚本与继承入口分别绑定 |
| 每组 GUARD_RESULT / stdout.log / stderr.log / actual_HOST_* | PID、两退出码、输出、内存传感、Job/Reader/句柄清理 |
| *_PUBLIC_V30_DIFF.patch / CANDIDATE_DIFF_BINDING.json | 两个独立候选相对 public-v30 的源码差异 |
| ORIGINAL_FILES_POSTRUN.json | 全 8,136 原文件保持证明 |
| EVIDENCE_TOOL_FAILURES / AUDIT_TOOL_FAILURES / PREMATURE_LAUNCH_FAILURE | 本轮工具错误记录，无混算游戏成绩 |
| DELIVERY_RESULT.json / REPORT.md | 本轮交付与范围说明 |
| ARCHIVE_RECEIPT.json / GIT_SAVE_RECEIPT.json | 封包与真实远端保存凭据 |

每个 `project`、`data` 和 `output` 均为自有可弃副本/合成数据，原目录路径保留。归档不组合这些项目；只携带证据、指定独立源码和合成数据。
'''
(E/'INDEX.md').write_text(guide,encoding='utf-8')
print(json.dumps({'original_files_unchanged':len(post),'results':[{'run':r['run'],'strict_pass':r['strict_pass'],'checks':r['checks'],'cases':r['cases'],'t03':r['t03_executed']} for r in results]},ensure_ascii=False))
