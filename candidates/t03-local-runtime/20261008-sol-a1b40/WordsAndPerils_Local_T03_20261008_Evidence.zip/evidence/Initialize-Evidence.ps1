$ErrorActionPreference='Stop'
$taskRoot='E:\WordsAndPerils-Tasks\candidate-20261008-ea04d75a'
$evidenceRoot=$PSScriptRoot
function Write-Json($name,$value) { $value | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $evidenceRoot $name) -Encoding utf8 }
function Hash-File($path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
$baseline=Get-ChildItem -LiteralPath $taskRoot -File -Recurse -Force | Where-Object { -not $_.FullName.StartsWith((Join-Path $taskRoot 'evidence')+'\') -and $_.FullName -notmatch '\\\.git(\\|$)' }
$index=@($baseline | ForEach-Object { [ordered]@{path=[IO.Path]::GetRelativePath($taskRoot,$_.FullName).Replace('\','/');bytes=$_.Length;sha256=Hash-File $_.FullName;last_write_utc=$_.LastWriteTimeUtc.ToString('o')} })
Write-Json 'DIRECTORY_INDEX_AND_HASHES.json' $index
$groups=@($index | Group-Object { ($_.path -split '/')[0] } | ForEach-Object { [ordered]@{directory=$_.Name;files=$_.Count;bytes=($_.Group | Measure-Object bytes -Sum).Sum} })
Write-Json 'DIRECTORY_SUMMARY.json' $groups
$processes=@(Get-Process | Where-Object {$_.ProcessName -match 'godot|powershell|pwsh'} | Select-Object Id,ProcessName,@{n='start_utc';e={$_.StartTime.ToUniversalTime().ToString('o')}})
$rules=@('E:\AGENTS.md','E:\WordsAndPerils-Tasks\AGENTS.md',(Join-Path $taskRoot 'AGENTS.md')) | Where-Object {Test-Path -LiteralPath $_}
$rules+=@(Get-ChildItem -LiteralPath $taskRoot -Filter AGENTS.md -Recurse -Force | Select-Object -ExpandProperty FullName)
Write-Json 'LOCAL_PREFLIGHT.json' ([ordered]@{utc=[DateTime]::UtcNow.ToString('o');root=$taskRoot;evidence=$evidenceRoot;processes=$processes;agents_files=@($rules | Select-Object -Unique);unknown_command_lines_read=$false;unknown_environment_read=$false;unknown_processes_killed=$false;godot_found=@($processes | Where-Object ProcessName -match 'godot').Count;version_and_probe_rerun=$false;model_requested='gpt-6.1-sol';model_runtime_identity='not exposed by callable tools';filesystem_inventory='all non-Git original files; source, resource, test and log hashes included';task_ownership_note='Existing TASK_OWNERSHIP retained; testing only fresh evidence-owned copies.'})
$audit=@()
$authority=Get-Content -LiteralPath (Join-Path $taskRoot 'public-candidates\natural-save-identity\package-evidence\BASE_AUTHORITY_INPUTS.json') -Raw | ConvertFrom-Json
foreach($kind in @('natural-save-identity','raw-short-write')) {
 $candidateRoot=Join-Path $taskRoot ('public-candidates\'+$kind+'\project')
 $package=Join-Path $taskRoot ('public-candidates\'+$kind+'\package-evidence')
 $manifest=Get-Content -LiteralPath (Join-Path $package 'MANIFEST.json') -Raw | ConvertFrom-Json
 $expected=@{}
 foreach($prop in $authority.files.PSObject.Properties) {$expected[$prop.Name]=$prop.Value}
 if($kind -eq 'natural-save-identity') { foreach($prop in $manifest.files.PSObject.Properties) {$expected[$prop.Name]=$prop.Value.candidate_sha256} }
 else {
  foreach($prop in $manifest.production_files.PSObject.Properties) {$expected[$prop.Name]=$prop.Value.candidate_sha256}
  foreach($prop in $manifest.new_test_files.PSObject.Properties) {$expected[$prop.Name]=$prop.Value.sha256}
  foreach($prop in $manifest.read_only_inputs.PSObject.Properties) { if($prop.Name -ne 'project.godot') {$expected[$prop.Name]=$prop.Value} }
 }
 foreach($path in ($expected.Keys | Sort-Object)) {
  $actual=Hash-File (Join-Path $candidateRoot $path)
  $audit+=[ordered]@{candidate=$kind;path=$path;expected_sha256=$expected[$path];actual_sha256=$actual;matches=$actual -eq $expected[$path]}
 }
 $receipt=Get-Content -LiteralPath (Join-Path $taskRoot ('public-candidates\'+$kind+'\PUBLIC_V30_CANDIDATE_VERIFIED_RECEIPT.json')) -Raw | ConvertFrom-Json
 $audit+=[ordered]@{candidate=$kind;path='package-evidence/MANIFEST.json';expected_sha256=$receipt.original_manifest_sha256;actual_sha256=Hash-File (Join-Path $package 'MANIFEST.json');matches=(Hash-File (Join-Path $package 'MANIFEST.json')) -eq $receipt.original_manifest_sha256}
 $audit+=[ordered]@{candidate=$kind;path='project.godot';expected_sha256=$receipt.project_godot_sha256;actual_sha256=Hash-File (Join-Path $candidateRoot 'project.godot');matches=(Hash-File (Join-Path $candidateRoot 'project.godot')) -eq $receipt.project_godot_sha256;old_raw_manifest_pin=$receipt.original_raw_manifest_project_pin;scope=$receipt.scope}
}
Write-Json 'MANIFEST_AND_AUTHORITY_AUDIT.json' $audit
$guard=@(Get-Content -LiteralPath (Join-Path $taskRoot 'windows-guard-v3\source-hashes.json') -Raw | ConvertFrom-Json | ForEach-Object { $actual=Hash-File (Join-Path $taskRoot ('windows-guard-v3\'+$_.name)); [ordered]@{name=$_.name;expected=$_.sha256;actual=$actual;matches=$actual -eq $_.sha256} })
Write-Json 'GUARD_SOURCE_AUDIT.json' $guard
$probe=Join-Path $taskRoot 'godot-small-probes-v3\local-user-probe-20261008-1049-6b73a1'
$receiptPath=Join-Path $probe 'PROBE_COMPLETION_RECEIPT.json'
if((Hash-File $receiptPath) -ne '7588f7eee645f386f03275405dba30927fac8b99e388c1d3af1e3868214641e9' -or (Get-Item -LiteralPath $receiptPath).Length -ne 82571) {throw 'Original probe receipt differs'}
$r=Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
Write-Json 'PROBE_RECEIPT_SCHEMA.json' @($r.PSObject.Properties | ForEach-Object { [ordered]@{field=$_.Name;type=$_.Value.GetType().Name} })
Write-Json 'PROBE_HONG_KONG_ERRATUM.json' ([ordered]@{original_receipt=$receiptPath;original_bytes=82571;original_sha256=Hash-File $receiptPath;original_utc_preserved=$true;original_receipt_modified=$false;correction='The original two hong_kong time fields mistakenly duplicate UTC. Correct UTC+08:00 values follow.';correct_started_hong_kong='2026-10-08T18:49:33.6029581+08:00';correct_ended_hong_kong='2026-10-08T18:49:34.3005407+08:00';utc_started='2026-10-08T10:49:33.6029581Z';utc_ended='2026-10-08T10:49:34.3005407Z';probe_rerun=$false})
$probeResult=Get-Content -LiteralPath (Join-Path $probe 'user-probe-result.json') -Raw | ConvertFrom-Json
$line=@($probeResult.Stdout -split '\r?\n' | Where-Object {$_ -like 'USER_ISOLATION_RESULT=*'})[0]
$markerReceipt=$line.Substring('USER_ISOLATION_RESULT='.Length) | ConvertFrom-Json
$spec=Get-Content -LiteralPath (Join-Path $probe 'user-probe-spec.json') -Raw | ConvertFrom-Json
$code=Get-Content -LiteralPath (Join-Path $probe 'project\probe.gd') -Raw
$markerPath=$markerReceipt.marker_path
$globalPath=$markerReceipt.globalized_user
$osPath=$markerReceipt.user_data_dir
$probeFiles=@('user-probe-spec.json','project\probe.gd','project\project.godot','Prepare-Probe.ps1','Finalize-Probe.ps1','user-probe-result.json','user-probe-launch.json','local-exec-marker.txt') | ForEach-Object { [ordered]@{path=$_;sha256=Hash-File (Join-Path $probe $_);bytes=(Get-Item -LiteralPath (Join-Path $probe $_)).Length} }
Write-Json 'PROBE_EVIDENCE_AUDIT.json' ([ordered]@{receipt_sha256=Hash-File $receiptPath;files=@($probeFiles);os_get_user_data_dir=$osPath;project_settings_globalize_user=$globalPath;two_api_paths_equal=$osPath -eq $globalPath;expected_data_root=$spec.isolated_data_root;marker_path=$markerPath;marker_expected_sha256=$markerReceipt.marker_sha256;marker_actual_sha256=Hash-File $markerPath;marker_hash_matches=(Hash-File $markerPath) -eq $markerReceipt.marker_sha256;marker_readback=$markerReceipt.marker_readback_ok;path_check_offset=$code.IndexOf('if not isolated:');write_offset=$code.IndexOf('FileAccess.open(marker, FileAccess.WRITE)');path_check_before_write=$code.IndexOf('if not isolated:') -lt $code.IndexOf('FileAccess.open(marker, FileAccess.WRITE)');failure_returns_before_write=$code.Contains("quit(3)`n`t`treturn");autoloads=$markerReceipt.autoloads;godot_rerun=$false})
if(@($audit | Where-Object {-not $_.matches}).Count -or @($guard | Where-Object {-not $_.matches}).Count) {throw 'Source or manifest mismatch; retained and reported, do not launch'}
[ordered]@{files=$index.Count;authority_audit_rows=$audit.Count;source_mismatches=@($audit | Where-Object {-not $_.matches}).Count;guard_mismatches=@($guard | Where-Object {-not $_.matches}).Count;probe_marker=$markerPath;erratum_written=$true}|ConvertTo-Json
