extends "res://tests/natural_coast_basic/test_adapter.gd"

func _initialize() -> void:
	var expected_root := OS.get_cmdline_user_args()[0].replace("\\", "/").simplify_path().trim_suffix("/")
	var os_dir := OS.get_user_data_dir().replace("\\", "/").simplify_path().trim_suffix("/")
	var global_dir := ProjectSettings.globalize_path("user://").replace("\\", "/").simplify_path().trim_suffix("/")
	var autoloads: Array = []
	for property in ProjectSettings.get_property_list():
		if str(property.name).begins_with("autoload/"): autoloads.append(property.name)
	var isolated := os_dir.to_lower().begins_with((expected_root+"/appdata/Godot/app_userdata/").to_lower()) and os_dir.to_lower() == global_dir.to_lower() and autoloads.is_empty()
	print("LOCAL_SUITE_ISOLATION ",JSON.stringify({"isolated":isolated,"os_user_dir":os_dir,"globalized_user_dir":global_dir,"autoloads":autoloads,"run_id":"natural-adapter-plateau-fixed-01"}))
	if not isolated:
		quit(3)
		return
	OS.set_environment("COAST_PLAY_RECIPE","plateau_hinterland")
	OS.set_environment("COAST_PLAY_RUN_ID","natural-adapter-plateau-fixed-01")
	OS.set_environment("COAST_PLAY_OUTPUT","E:/WordsAndPerils-Tasks/candidate-20261008-ea04d75a/evidence/local-dev-20261008-sol-a1b40/natural-adapter-plateau-fixed-01/output")
	super._initialize()
func check(ok: bool, label_: String) -> bool:
	var original_result := super.check(ok,label_)
	if label_.begins_with("T03 "):
		print("T03_EXECUTED ",JSON.stringify({"label":label_,"passed":ok}))
	return original_result

