extends SceneTree

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 1:
		quit(2)
		return
	var root := args[0].replace("\\", "/").simplify_path().trim_suffix("/")
	var user_dir := OS.get_user_data_dir().replace("\\", "/").simplify_path().trim_suffix("/")
	var globalized := ProjectSettings.globalize_path("user://").replace("\\", "/").simplify_path().trim_suffix("/")
	var autoloads: Array[String] = []
	for property in ProjectSettings.get_property_list():
		var property_name := str(property.name)
		if property_name.begins_with("autoload/"):
			autoloads.append(property_name)
	var expected_prefix := (root + "/appdata/Godot/app_userdata/").to_lower()
	var isolated := user_dir.to_lower().begins_with(expected_prefix) and globalized.to_lower().begins_with(expected_prefix) and user_dir.to_lower() == globalized.to_lower() and autoloads.is_empty()
	var result := {"user_data_dir": user_dir, "globalized_user": globalized, "expected_root": root, "isolated": isolated, "autoloads": autoloads, "application_name": ProjectSettings.get_setting("application/config/name")}
	if not isolated:
		print("USER_ISOLATION_RESULT=" + JSON.stringify(result))
		quit(3)
		return
	var marker := "user://isolation-probe.txt"
	var file := FileAccess.open(marker, FileAccess.WRITE)
	if file == null:
		quit(4)
		return
	file.store_string("USER_ISOLATION_OK\n")
	file.close()
	file = FileAccess.open(marker, FileAccess.READ)
	if file == null:
		quit(5)
		return
	var content := file.get_as_text()
	file.close()
	result["marker_path"] = ProjectSettings.globalize_path(marker)
	result["marker_sha256"] = FileAccess.get_sha256(marker)
	result["marker_readback_ok"] = content == "USER_ISOLATION_OK\n"
	print("USER_ISOLATION_RESULT=" + JSON.stringify(result))
	if content != "USER_ISOLATION_OK\n":
		quit(6)
		return
	print("USER_ISOLATION_OK")
	quit(0)
