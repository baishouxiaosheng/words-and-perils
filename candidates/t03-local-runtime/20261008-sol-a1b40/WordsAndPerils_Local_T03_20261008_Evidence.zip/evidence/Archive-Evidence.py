from pathlib import Path
import json,hashlib,zipfile,datetime
E=Path(__file__).resolve().parent
ROOT=E.parent.parent
def h(data): return hashlib.sha256(data).hexdigest()
archive=E/'WordsAndPerils_Local_T03_20261008_Evidence.zip'
if archive.exists(): raise RuntimeError('Preserve existing archive; no overwrite')
members={}
for p in E.rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(E)
    if 'project' in rel.parts or '.git' in rel.parts: continue
    if p.suffix in ['.zip','.b64']: continue
    members['evidence/'+rel.as_posix()]=p.read_bytes()

# Keep each candidate's source/provenance separate; this is not a combined runnable project.
selected={
 'raw-short-write':['project/core/ai_gm_rebuilt/engine.gd','project/tests/t03_raw_short_write/test_save_file.gd','project/tests/t03_raw_short_write/io_probe.gd','package-evidence/MANIFEST.json','package-evidence/T03_RAW_SHORT_WRITE.patch','PUBLIC_V30_CANDIDATE_VERIFIED_RECEIPT.json'],
 'natural-save-identity':['project/view/generated_natural_coast_basic/adapter.gd','project/view/generated_natural_coast_basic/engine.gd','project/tests/natural_coast_basic/test_compile.gd','project/tests/natural_coast_basic/test_adapter.gd','package-evidence/MANIFEST.json','package-evidence/BASE_AUTHORITY_INPUTS.json','PUBLIC_V30_CANDIDATE_VERIFIED_RECEIPT.json']
}
for candidate, files in selected.items():
    for rel in files: members['independent-original-candidates/'+candidate+'/'+rel]=(ROOT/'public-candidates'/candidate/rel).read_bytes()
for rel in ['windows-guard-v3/WindowsGuard.cs','windows-guard-v3/Invoke-WindowsGuard.ps1','windows-guard-v3/source-hashes.json','godot-small-probes-v3/local-user-probe-20261008-1049-6b73a1/PROBE_COMPLETION_RECEIPT.json','godot-small-probes-v3/local-user-probe-20261008-1049-6b73a1/project/probe.gd','godot-small-probes-v3/local-user-probe-20261008-1049-6b73a1/user-probe-spec.json']:
    members['unchanged-provenance/'+rel]=(ROOT/rel).read_bytes()
for run in ['natural-compile-01','raw-short-write-01','natural-adapter-coastal-01','natural-adapter-coastal-fixed-02','natural-adapter-plateau-fixed-01']:
    members['evidence/'+run+'/inherited_test_entry.gd']=(E/run/'project/_local_test_entry.gd').read_bytes()

manifest=[{'path':n,'bytes':len(b),'sha256':h(b)} for n,b in sorted(members.items())]
members['ARCHIVE_MEMBERS.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(members.items()): z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert sorted(z.namelist())==sorted(members)
    for n,b in members.items(): assert z.read(n)==b
data=archive.read_bytes()
git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
receipt={'archive':str(archive),'bytes':len(data),'sha256':h(data),'git_blob_sha':git_blob_sha,'members':len(members),'all_crc_path_size_sha_and_bytes_verified':True,'standalone_runnable':False,'independent_candidates_not_combined':True,'real_player_data_included':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(E/'ARCHIVE_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
