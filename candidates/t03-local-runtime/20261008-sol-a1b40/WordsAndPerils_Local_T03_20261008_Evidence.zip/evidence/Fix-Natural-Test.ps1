$ErrorActionPreference='Stop'
$taskRoot='E:\WordsAndPerils-Tasks\candidate-20261008-ea04d75a'
$original=Join-Path $taskRoot 'public-candidates\natural-save-identity\project\tests\natural_coast_basic\test_adapter.gd'
$originalHash=(Get-FileHash -LiteralPath $original).Hash.ToLowerInvariant()
if($originalHash -ne '99d750960ed2ba6197b5e624044a31276accd78c32aea78e000661179d2c66df') {throw 'Unknown source change; preserve'}
$fixRoot=Join-Path $PSScriptRoot 'natural-test-type-fix'
New-Item -ItemType Directory -Path (Join-Path $fixRoot 'overlay\tests\natural_coast_basic') | Out-Null
$old=[IO.File]::ReadAllText($original)
$new=$old.Replace('var existing := adapter.save_data()','var existing: Dictionary = adapter.save_data()').Replace('var raw := adapter.engine.save_data()','var raw: Dictionary = adapter.engine.save_data()').Replace('var foreign_raw := independent.engine.save_data()','var foreign_raw: Dictionary = independent.engine.save_data()')
if($new -eq $old) {throw 'No correction made'}
$fixed=Join-Path $fixRoot 'overlay\tests\natural_coast_basic\test_adapter.gd'
[IO.File]::WriteAllText($fixed,$new,[Text.UTF8Encoding]::new($false))
[ordered]@{status='independent_unadopted_test_only_correction';original_source=$original;original_sha256=$originalHash;corrected_test=$fixed;corrected_sha256=(Get-FileHash -LiteralPath $fixed).Hash.ToLowerInvariant();production_files_changed=@();test_corrections=@('existing: Dictionary','raw: Dictionary','foreign_raw: Dictionary');cause='GDScript cannot infer return types from methods on a parameter declared RefCounted. Three reported errors at test lines 45, 64, 71.';behavior='Explicit existing Dictionary types only; same assertions and fixtures';old_manifest_retained=$true;failure_records=@('natural-adapter-coastal-01/GUARD_RESULT.json','natural-adapter-parse-diagnostic-01/GUARD_RESULT.json');adopted=$false} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $fixRoot 'FIX_MANIFEST.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $fixRoot 'FIX_MANIFEST.json')
