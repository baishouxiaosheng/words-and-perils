param([Parameter(Mandatory=$true)][string]$RunName,[Parameter(Mandatory=$true)][ValidateSet('natural-save-identity','raw-short-write')][string]$Candidate,[Parameter(Mandatory=$true)][string]$Suite,[string]$Recipe='',[switch]$FixTestTypes)
$ErrorActionPreference='Stop'
$taskRoot='E:\WordsAndPerils-Tasks\candidate-20261008-ea04d75a'
$runRoot=Join-Path $PSScriptRoot $RunName
if(Test-Path -LiteralPath $runRoot) {throw 'Run directory exists; preserve previous evidence'}
if(Get-Process | Where-Object ProcessName -match 'Godot') {throw 'Unknown Godot found; no launch or interruption'}
New-Item -ItemType Directory -Path $runRoot | Out-Null
$project=Join-Path $runRoot 'project'
$source=Join-Path $taskRoot ('public-candidates\'+$Candidate+'\project')
$copyStarted=[DateTime]::UtcNow.ToString('o')
Copy-Item -LiteralPath $source -Destination $project -Recurse
foreach($leaf in @('data','data\appdata','data\localappdata','data\temp','output')) {New-Item -ItemType Directory -Path (Join-Path $runRoot $leaf) | Out-Null}
$baseline=@(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'DIRECTORY_INDEX_AND_HASHES.json') -Raw | ConvertFrom-Json)
$prefix='public-candidates/'+$Candidate+'/project/'
$sourceMap=@($baseline | Where-Object {$_.path.StartsWith($prefix)} | ForEach-Object {
 $relative=$_.path.Substring($prefix.Length)
 $current=(Get-FileHash -LiteralPath (Join-Path $source $relative)).Hash.ToLowerInvariant()
 $copyHash=(Get-FileHash -LiteralPath (Join-Path $project $relative)).Hash.ToLowerInvariant()
 [ordered]@{path=$relative;source_sha256=$current;copy_sha256=$copyHash;baseline_sha256=$_.sha256;matches=($current -eq $_.sha256 -and $copyHash -eq $current)}
})
$sourceMap | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runRoot 'SOURCE_MAP.json') -Encoding utf8
if(@($sourceMap | Where-Object {-not $_.matches}).Count) {throw 'Unknown source change or copy mismatch; preserved'}
if($FixTestTypes) {
 if($Candidate -ne 'natural-save-identity' -or $Suite -ne 'tests/natural_coast_basic/test_adapter.gd') {throw 'Wrong correction scope'}
 $fix=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'natural-test-type-fix\FIX_MANIFEST.json') -Raw | ConvertFrom-Json
 if((Get-FileHash -LiteralPath $fix.corrected_test).Hash.ToLowerInvariant() -ne $fix.corrected_sha256) {throw 'Correction source changed'}
 Copy-Item -LiteralPath $fix.corrected_test -Destination (Join-Path $project $Suite)
 foreach($row in $sourceMap) {if($row.path -eq $Suite) {$row['copy_sha256']=$fix.corrected_sha256;$row['intentional_test_type_correction']=$true}}
 $sourceMap | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runRoot 'SOURCE_MAP.json') -Encoding utf8
}
$config=Get-Content -LiteralPath (Join-Path $project 'project.godot') -Raw
if($config -match '(?m)^\[autoload\]') {throw 'Autoload present; needs a separate documented no-Autoload test project'}
$entry=@'
extends "res://SUITE_PATH"

func _initialize() -> void:
	var expected_root := OS.get_cmdline_user_args()[0].replace("\\", "/").simplify_path().trim_suffix("/")
	var os_dir := OS.get_user_data_dir().replace("\\", "/").simplify_path().trim_suffix("/")
	var global_dir := ProjectSettings.globalize_path("user://").replace("\\", "/").simplify_path().trim_suffix("/")
	var autoloads: Array = []
	for property in ProjectSettings.get_property_list():
		if str(property.name).begins_with("autoload/"): autoloads.append(property.name)
	var isolated := os_dir.to_lower().begins_with((expected_root+"/appdata/Godot/app_userdata/").to_lower()) and os_dir.to_lower() == global_dir.to_lower() and autoloads.is_empty()
	print("LOCAL_SUITE_ISOLATION ",JSON.stringify({"isolated":isolated,"os_user_dir":os_dir,"globalized_user_dir":global_dir,"autoloads":autoloads,"run_id":"RUN_NAME"}))
	if not isolated:
		quit(3)
		return
	OS.set_environment("COAST_PLAY_RECIPE","RECIPE_NAME")
	OS.set_environment("COAST_PLAY_RUN_ID","RUN_NAME")
	OS.set_environment("COAST_PLAY_OUTPUT","OUTPUT_PATH")
SUPER_INITIALIZE
'@
$entry=$entry.Replace('SUITE_PATH',$Suite).Replace('RUN_NAME',$RunName).Replace('RECIPE_NAME',$Recipe).Replace('OUTPUT_PATH',(Join-Path $runRoot 'output').Replace('\','/'))
if($Candidate -eq 'natural-save-identity') {$entry=$entry.Replace('SUPER_INITIALIZE',"`tsuper._initialize()")} else {$entry=$entry.Replace('SUPER_INITIALIZE','')}
if($Suite -eq 'tests/natural_coast_basic/test_adapter.gd') {
 $entry+="`nfunc check(ok: bool, label_: String) -> bool:`n`tvar original_result := super.check(ok,label_)`n`tif label_.begins_with(`"T03 `"):`n`t`tprint(`"T03_EXECUTED `",JSON.stringify({`"label`":label_,`"passed`":ok}))`n`treturn original_result`n"
}
[IO.File]::WriteAllText((Join-Path $project '_local_test_entry.gd'),$entry.Replace("`r`n","`n")+"`n",[Text.UTF8Encoding]::new($false))
$spec=[ordered]@{executable='E:\WordsAndPerils-Test\Godot\4.6.3\Godot_v4.6.3-stable_win64.exe';arguments=@('--headless','--path',$project,'--script','res://_local_test_entry.gd','--',(Join-Path $runRoot 'data'));working_directory=$project;isolated_data_root=(Join-Path $runRoot 'data');profile='small';timeout_seconds=120;log_path=(Join-Path $runRoot 'GUARD_RESULT.json')}
$spec | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runRoot 'SPEC.json') -Encoding utf8
[ordered]@{candidate=$Candidate;suite=$Suite;recipe=$Recipe;run_id=$RunName;source=$source;project=$project;copied_files=$sourceMap.Count;copy_started_utc=$copyStarted;copy_ended_utc=[DateTime]::UtcNow.ToString('o');original_project_godot_sha256=(Get-FileHash -LiteralPath (Join-Path $source 'project.godot')).Hash.ToLowerInvariant();test_project_godot_sha256=(Get-FileHash -LiteralPath (Join-Path $project 'project.godot')).Hash.ToLowerInvariant();suite_sha256=(Get-FileHash -LiteralPath (Join-Path $project $Suite)).Hash.ToLowerInvariant();entry_sha256=(Get-FileHash -LiteralPath (Join-Path $project '_local_test_entry.gd')).Hash.ToLowerInvariant();no_autoload=$true;combined_candidates=$false;scope='public-v30 independent unadopted candidate, fresh disposable full byte copy; isolated data; inherited original suite; additive path-check entry only'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runRoot 'PREPARATION.json') -Encoding utf8
Write-Output ('Prepared '+$RunName+'; matched '+$sourceMap.Count+' files; no original project changes.')
